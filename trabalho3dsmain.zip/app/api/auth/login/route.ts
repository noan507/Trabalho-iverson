import { NextRequest, NextResponse } from 'next/server'
import { usersDB } from '@/lib/users-db'

export async function POST(request: NextRequest) {
  try {
    const { email, password, userType } = await request.json()

    console.log('=== LOGIN ===')
    console.log('Tentativa de login:', { email, userType })
    console.log('Total de usuários no sistema:', usersDB.getUsersCount())
    console.log('Usuários disponíveis:', usersDB.getAllUsers().map(u => ({ 
      email: u.email, 
      type: u.user_type,
      active: u.is_active 
    })))

    // Simular delay de rede
    await new Promise(resolve => setTimeout(resolve, 500))

    // Validações básicas
    if (!email || !password || !userType) {
      console.log('Erro: Campos obrigatórios faltando')
      return NextResponse.json(
        { error: 'Email, senha e tipo de usuário são obrigatórios' },
        { status: 400 }
      )
    }

    // Buscar usuário
    const user = usersDB.findUser(email, userType)
    console.log('Usuário encontrado:', user ? `Sim - ${user.full_name}` : 'Não')

    if (!user) {
      console.log('Erro: Usuário não encontrado')
      console.log('Email procurado:', email.toLowerCase())
      console.log('Tipo procurado:', userType)
      
      // Verificar se existe com outro tipo
      const userWithDifferentType = usersDB.findUserByEmail(email)
      if (userWithDifferentType) {
        console.log('Usuário existe mas com tipo diferente:', userWithDifferentType.user_type)
        return NextResponse.json(
          { error: `Este email está cadastrado como ${userWithDifferentType.user_type}, não como ${userType}` },
          { status: 401 }
        )
      }
      
      return NextResponse.json(
        { error: 'Email não encontrado. Verifique se você se registrou ou use um dos emails padrão.' },
        { status: 401 }
      )
    }

    // Verificar senha (aceitar qualquer senha por enquanto para facilitar testes)
    if (password.length < 3) {
      console.log('Erro: Senha muito curta')
      return NextResponse.json(
        { error: 'Senha muito curta' },
        { status: 401 }
      )
    }

    console.log('Login bem-sucedido para:', user.email)

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
        full_name: user.full_name,
        user_type: user.user_type,
        area: user.area
      },
      message: 'Login realizado com sucesso'
    })

  } catch (error) {
    console.error('Erro no login:', error)
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}
