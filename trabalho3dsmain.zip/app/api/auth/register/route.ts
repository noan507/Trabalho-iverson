import { NextRequest, NextResponse } from 'next/server'
import { usersDB } from '@/lib/users-db'

export async function POST(request: NextRequest) {
  try {
    const { fullName, email, password, userType, area } = await request.json()

    console.log('=== REGISTRO ===')
    console.log('Dados recebidos:', { fullName, email, userType, area })

    // Simular delay de rede
    await new Promise(resolve => setTimeout(resolve, 500))

    // Validações básicas
    if (!fullName || !email || !password || !userType) {
      console.log('Erro: Campos obrigatórios faltando')
      return NextResponse.json(
        { error: 'Todos os campos obrigatórios devem ser preenchidos' },
        { status: 400 }
      )
    }

    if (password.length < 3) {
      console.log('Erro: Senha muito curta')
      return NextResponse.json(
        { error: 'Senha deve ter pelo menos 3 caracteres' },
        { status: 400 }
      )
    }

    // Verificar se email já existe
    const existingUser = usersDB.findUserByEmail(email)
    console.log('Usuário existente encontrado:', existingUser ? 'Sim' : 'Não')

    if (existingUser) {
      return NextResponse.json(
        { error: 'Este email já está cadastrado' },
        { status: 400 }
      )
    }

    // Criar novo usuário
    const newUser = usersDB.addUser({
      email: email.toLowerCase(),
      password: password, // Em produção, fazer hash da senha
      full_name: fullName,
      user_type: userType,
      area: area || null
    })

    console.log('Usuário registrado com sucesso:', newUser.email)
    console.log('Total de usuários agora:', usersDB.getUsersCount())
    console.log('Todos os usuários:', usersDB.getAllUsers().map(u => ({ email: u.email, type: u.user_type })))

    return NextResponse.json({
      message: 'Usuário registrado com sucesso! Você pode fazer login agora.',
      user: {
        id: newUser.id,
        email: newUser.email,
        full_name: newUser.full_name,
        user_type: newUser.user_type
      }
    })

  } catch (error) {
    console.error('Erro no registro:', error)
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}
