import { NextRequest, NextResponse } from 'next/server'

// Dados mock para demonstração
let mockBathroomRequests = [
  {
    id: '1',
    student_name: 'Pedro Santos',
    class_id: '1',
    professor_id: '1',
    exit_time: new Date().toISOString(),
    return_time: null,
    status: 'student_left',
    max_duration_minutes: 10,
    created_at: new Date().toISOString(),
    classes: { name: '3º Ano D.S.', code: '3DS' },
    users: { full_name: 'Maria Silva' }
  }
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const professorId = searchParams.get('professorId')
    const status = searchParams.get('status')

    // Simular delay de rede
    await new Promise(resolve => setTimeout(resolve, 300))

    let filteredRequests = [...mockBathroomRequests]

    if (professorId) {
      filteredRequests = filteredRequests.filter(req => req.professor_id === professorId)
    }

    if (status) {
      filteredRequests = filteredRequests.filter(req => req.status === status)
    }

    return NextResponse.json({ data: filteredRequests })

  } catch (error) {
    console.error('Erro na API:', error)
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      studentName,
      classId,
      professorId,
      maxDurationMinutes = 10
    } = body

    // Simular delay de rede
    await new Promise(resolve => setTimeout(resolve, 300))

    const newRequest = {
      id: Date.now().toString(),
      student_name: studentName,
      class_id: classId || '1',
      professor_id: professorId,
      exit_time: new Date().toISOString(),
      return_time: null,
      status: 'pending',
      max_duration_minutes: maxDurationMinutes,
      created_at: new Date().toISOString(),
      classes: { name: '3º Ano D.S.', code: '3DS' },
      users: { full_name: 'Professor' }
    }

    mockBathroomRequests.unshift(newRequest)

    return NextResponse.json({ data: newRequest })

  } catch (error) {
    console.error('Erro na API:', error)
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, status, returnTime } = body

    // Simular delay de rede
    await new Promise(resolve => setTimeout(resolve, 300))

    const requestIndex = mockBathroomRequests.findIndex(req => req.id === id)
    
    if (requestIndex === -1) {
      return NextResponse.json(
        { error: 'Solicitação não encontrada' },
        { status: 404 }
      )
    }

    mockBathroomRequests[requestIndex] = {
      ...mockBathroomRequests[requestIndex],
      status,
      return_time: returnTime || mockBathroomRequests[requestIndex].return_time
    }

    return NextResponse.json({ data: mockBathroomRequests[requestIndex] })

  } catch (error) {
    console.error('Erro na API:', error)
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}
