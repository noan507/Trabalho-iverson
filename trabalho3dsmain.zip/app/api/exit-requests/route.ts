import { NextRequest, NextResponse } from 'next/server'

// Dados mock para demonstração
let mockExitRequests = [
  {
    id: '1',
    student_name: 'João Silva',
    class_id: '1',
    professor_id: '1',
    exit_time: '10:30',
    valid_until: '11:30',
    reason: 'Consulta médica',
    status: 'approved',
    created_at: new Date().toISOString(),
    classes: { name: '3º Ano D.S.', code: '3DS' },
    users: { full_name: 'Maria Silva' }
  },
  {
    id: '2',
    student_name: 'Ana Costa',
    class_id: '1',
    professor_id: '1',
    exit_time: '14:00',
    valid_until: '15:00',
    reason: 'Emergência familiar',
    status: 'student_left',
    created_at: new Date().toISOString(),
    classes: { name: '3º Ano D.S.', code: '3DS' },
    users: { full_name: 'Maria Silva' }
  }
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const professorId = searchParams.get('professorId')
    const status = searchParams.get('status')

    // Simular delay de rede
    await new Promise(resolve => setTimeout(resolve, 300))

    let filteredRequests = [...mockExitRequests]

    if (professorId) {
      filteredRequests = filteredRequests.filter(req => req.professor_id === professorId)
    }

    if (status) {
      filteredRequests = filteredRequests.filter(req => req.status === status)
    }

    return NextResponse.json({ data: filteredRequests })

  } catch (error) {
    console.error('Erro na API:', error)
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      studentName,
      classId,
      professorId,
      exitTime,
      validUntil,
      reason
    } = body

    // Simular delay de rede
    await new Promise(resolve => setTimeout(resolve, 300))

    const newRequest = {
      id: Date.now().toString(),
      student_name: studentName,
      class_id: classId || '1',
      professor_id: professorId,
      exit_time: exitTime,
      valid_until: validUntil,
      reason,
      status: 'approved',
      created_at: new Date().toISOString(),
      classes: { name: '3º Ano D.S.', code: '3DS' },
      users: { full_name: 'Professor' }
    }

    mockExitRequests.unshift(newRequest)

    return NextResponse.json({ data: newRequest })

  } catch (error) {
    console.error('Erro na API:', error)
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}
