import Link from 'next/link'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { GraduationCap, Users, Shield, School } from 'lucide-react'

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl shadow-lg mb-6">
            <School className="text-white text-3xl h-12 w-12" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">
            Sistema <span className="text-blue-400">CESF</span>
          </h1>
          <p className="text-slate-300 text-lg">Controle de Saída de Alunos</p>
        </div>

        <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl">
          <CardHeader className="text-center pb-4">
            <CardTitle className="text-white text-xl font-semibold">
              Área de Acesso
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 p-6">
            <Link href="/login?type=professor" className="block">
              <Button className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white py-6 text-lg font-semibold transition-all duration-300 hover:scale-105 shadow-lg">
                <GraduationCap className="mr-3 h-6 w-6" />
                Acesso Professor
              </Button>
            </Link>
            
            <Link href="/login?type=coordenador" className="block">
              <Button className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white py-6 text-lg font-semibold transition-all duration-300 hover:scale-105 shadow-lg">
                <Users className="mr-3 h-6 w-6" />
                Acesso Coordenação
              </Button>
            </Link>

            <Link href="/login?type=fiscal" className="block">
              <Button className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-6 text-lg font-semibold transition-all duration-300 hover:scale-105 shadow-lg">
                <Shield className="mr-3 h-6 w-6" />
                Acesso Fiscal
              </Button>
            </Link>
            
            <div className="pt-4 border-t border-white/20">
              <Link href="/register" className="block">
                <Button variant="outline" className="w-full bg-white/10 text-white border-white/30 hover:bg-white/20 py-6 text-lg font-semibold transition-all duration-300 hover:scale-105 backdrop-blur-sm">
                  Criar Nova Conta
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <div className="text-center mt-6">
          <p className="text-slate-400 text-sm">
            Centro Educacional São Francisco
          </p>
        </div>
      </div>
    </div>
  )
}
