import { Card, CardContent } from "@/components/ui/card"
import { School } from "lucide-react"

export default function LoginLoading() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl shadow-lg mb-6">
            <School className="text-white h-12 w-12" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">
            Sistema <span className="text-blue-400">CESF</span>
          </h1>
          <p className="text-slate-300">Carregando...</p>
        </div>

        <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl">
          <CardContent className="p-8">
            <div className="space-y-6">
              {/* Loading skeleton */}
              <div className="space-y-4">
                <div className="h-4 bg-white/20 rounded animate-pulse"></div>
                <div className="h-10 bg-white/10 rounded animate-pulse"></div>
              </div>

              <div className="space-y-4">
                <div className="h-4 bg-white/20 rounded animate-pulse"></div>
                <div className="h-10 bg-white/10 rounded animate-pulse"></div>
              </div>

              <div className="h-12 bg-blue-600/50 rounded animate-pulse"></div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
