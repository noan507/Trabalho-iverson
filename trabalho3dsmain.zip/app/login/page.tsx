"use client"

import type React from "react"

import { useState, Suspense } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { GraduationCap, Users, Shield, School, ArrowLeft } from "lucide-react"

function LoginForm() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [area, setArea] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const router = useRouter()
  const searchParams = useSearchParams()
  const userType = searchParams.get("type") || "professor"

  const getIcon = () => {
    switch (userType) {
      case "coordenador":
        return <Users className="h-8 w-8" />
      case "fiscal":
        return <Shield className="h-8 w-8" />
      default:
        return <GraduationCap className="h-8 w-8" />
    }
  }

  const getTitle = () => {
    switch (userType) {
      case "coordenador":
        return "Acesso Coordenação"
      case "fiscal":
        return "Acesso Fiscal"
      default:
        return "Acesso Professor"
    }
  }

  const getGradient = () => {
    switch (userType) {
      case "coordenador":
        return "from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800"
      case "fiscal":
        return "from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800"
      default:
        return "from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")

    if (!email || !password) {
      setError("Email e senha são obrigatórios")
      setLoading(false)
      return
    }

    if (password.length < 3) {
      setError("Senha deve ter pelo menos 3 caracteres")
      setLoading(false)
      return
    }

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, userType, area }),
      })

      const data = await response.json()

      if (response.ok) {
        localStorage.setItem("user", JSON.stringify(data.user))

        switch (userType) {
          case "professor":
            router.push("/professor/dashboard")
            break
          case "coordenador":
            router.push("/coordenador/dashboard")
            break
          case "fiscal":
            router.push("/fiscal/dashboard")
            break
        }
      } else {
        setError(data.error || "Erro ao fazer login")
      }
    } catch (error) {
      setError("Erro de conexão com o servidor")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Button
            onClick={() => router.push("/")}
            variant="ghost"
            size="sm"
            className="absolute top-4 left-4 text-white hover:bg-white/10"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>

          <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl shadow-lg mb-6">
            <School className="text-white h-12 w-12" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2 flex items-center justify-center gap-3">
            {getIcon()}
            {getTitle()}
          </h1>
          <p className="text-slate-300">Sistema CESF</p>
        </div>

        <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl">
          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <Alert className="bg-red-500/20 border-red-500/30 text-red-100 backdrop-blur-sm">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="email" className="text-white font-medium">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seu.email@cesf.edu.br"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-white font-medium">
                  Senha
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Digite sua senha"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm"
                  required
                />
              </div>

              {userType === "coordenador" && (
                <div className="space-y-2">
                  <Label htmlFor="area" className="text-white font-medium">
                    Área de Atuação
                  </Label>
                  <Input
                    id="area"
                    type="text"
                    placeholder="Ex: Pedagógico, Disciplinar"
                    value={area}
                    onChange={(e) => setArea(e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm"
                    required
                  />
                </div>
              )}

              <Button
                type="submit"
                disabled={loading}
                className={`w-full bg-gradient-to-r ${getGradient()} text-white py-6 text-lg font-semibold transition-all duration-300 shadow-lg`}
              >
                {loading ? "Entrando..." : "Entrar"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
          <div className="w-full max-w-md">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl shadow-lg mb-6">
                <School className="text-white h-12 w-12" />
              </div>
              <h1 className="text-3xl font-bold text-white mb-2">
                Sistema <span className="text-blue-400">CESF</span>
              </h1>
              <p className="text-slate-300">Carregando...</p>
            </div>
            <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl">
              <CardContent className="p-8">
                <div className="space-y-6">
                  <div className="space-y-4">
                    <div className="h-4 bg-white/20 rounded animate-pulse"></div>
                    <div className="h-10 bg-white/10 rounded animate-pulse"></div>
                  </div>
                  <div className="space-y-4">
                    <div className="h-4 bg-white/20 rounded animate-pulse"></div>
                    <div className="h-10 bg-white/10 rounded animate-pulse"></div>
                  </div>
                  <div className="h-12 bg-blue-600/50 rounded animate-pulse"></div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      }
    >
      <LoginForm />
    </Suspense>
  )
}
