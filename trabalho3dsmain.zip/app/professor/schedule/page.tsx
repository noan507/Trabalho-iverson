'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Clock, School, BookOpen, Users } from 'lucide-react'

export default function SchedulePage() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  // Dados mock das aulas de hoje
  const todayClasses = [
    {
      id: 1,
      time: '07:30',
      subject: 'Matemática',
      class: '3º D.S.',
      room: 'Sala 15',
      status: 'current'
    },
    {
      id: 2,
      time: '08:20',
      subject: 'Física',
      class: '2º A',
      room: 'Lab. Física',
      status: 'upcoming'
    },
    {
      id: 3,
      time: '09:20',
      subject: 'Ciência da Computação',
      class: '3º D.S.',
      room: 'Lab. Info',
      status: 'upcoming'
    },
    {
      id: 4,
      time: '10:10',
      subject: 'História',
      class: '1º B',
      room: 'Sala 08',
      status: 'upcoming'
    },
    {
      id: 5,
      time: '11:50',
      subject: 'Design Gráfico',
      class: '3º D.S.',
      room: 'Lab. Design',
      status: 'upcoming'
    },
    {
      id: 6,
      time: '14:00',
      subject: 'Matemática',
      class: '2º B',
      room: 'Sala 12',
      status: 'upcoming'
    }
  ]

  useEffect(() => {
    const userData = localStorage.getItem('user')
    if (!userData) {
      router.push('/login?type=professor')
      return
    }
    
    const parsedUser = JSON.parse(userData)
    if (parsedUser.user_type !== 'professor') {
      router.push('/')
      return
    }
    
    setUser(parsedUser)
  }, [router])

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'current':
        return <Badge className="bg-green-600 hover:bg-green-700 text-white border-0">Em Andamento</Badge>
      case 'completed':
        return <Badge className="bg-slate-600 hover:bg-slate-700 text-white border-0">Concluída</Badge>
      case 'upcoming':
        return <Badge className="bg-blue-600 hover:bg-blue-700 text-white border-0">Próxima</Badge>
      default:
        return <Badge className="bg-slate-600 hover:bg-slate-700 text-white border-0">Agendada</Badge>
    }
  }

  const getSubjectColor = (subject: string) => {
    const colors = {
      'Matemática': 'from-blue-600 to-blue-700',
      'Física': 'from-purple-600 to-purple-700',
      'Ciência da Computação': 'from-green-600 to-green-700',
      'História': 'from-orange-600 to-orange-700',
      'Design Gráfico': 'from-pink-600 to-pink-700',
      'Português': 'from-indigo-600 to-indigo-700'
    }
    return colors[subject as keyof typeof colors] || 'from-slate-600 to-slate-700'
  }

  if (!user) return null

  const currentTime = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
  const currentDate = new Date().toLocaleDateString('pt-BR', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            onClick={() => router.back()}
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-emerald-600 to-emerald-800 rounded-xl shadow-lg">
            <Clock className="text-white h-8 w-8" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">Aulas de Hoje</h1>
            <p className="text-slate-300">Sistema CESF - {user.full_name}</p>
          </div>
        </div>

        {/* Informações do Dia */}
        <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl mb-8">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-white mb-2">{currentTime}</div>
                <p className="text-slate-300">Horário Atual</p>
              </div>
              <div className="text-center">
                <div className="text-xl font-semibold text-white mb-2 capitalize">{currentDate}</div>
                <p className="text-slate-300">Data de Hoje</p>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-emerald-400 mb-2">{todayClasses.length}</div>
                <p className="text-slate-300">Aulas Programadas</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lista de Aulas */}
        <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Cronograma de Aulas
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              {todayClasses.map((classItem) => (
                <div
                  key={classItem.id}
                  className={`rounded-lg p-6 border transition-all duration-200 hover:scale-[1.02] ${
                    classItem.status === 'current' 
                      ? 'bg-green-500/20 border-green-500/30 shadow-lg shadow-green-500/20' 
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-white">{classItem.time}</div>
                        <div className="text-slate-400 text-sm">Horário</div>
                      </div>
                      <div className={`w-1 h-16 bg-gradient-to-b ${getSubjectColor(classItem.subject)} rounded-full`}></div>
                      <div>
                        <h3 className="text-xl font-semibold text-white mb-1">{classItem.subject}</h3>
                        <div className="flex items-center gap-4 text-slate-300 text-sm">
                          <div className="flex items-center gap-1">
                            <Users className="h-4 w-4" />
                            <span>{classItem.class}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <School className="h-4 w-4" />
                            <span>{classItem.room}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    {getStatusBadge(classItem.status)}
                  </div>
                  
                  {classItem.status === 'current' && (
                    <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-4 mt-4">
                      <div className="flex items-center gap-2 text-green-200">
                        <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                        <span className="font-medium">Aula em andamento</span>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Resumo do Dia */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-xl">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-blue-400 mb-2">
                {todayClasses.filter(c => c.status === 'completed').length}
              </div>
              <p className="text-slate-300">Aulas Concluídas</p>
            </CardContent>
          </Card>
          
          <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-xl">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-green-400 mb-2">
                {todayClasses.filter(c => c.status === 'current').length}
              </div>
              <p className="text-slate-300">Em Andamento</p>
            </CardContent>
          </Card>
          
          <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-xl">
            <CardContent className="p-6 text-center">
              <div className="text-2xl font-bold text-yellow-400 mb-2">
                {todayClasses.filter(c => c.status === 'upcoming').length}
              </div>
              <p className="text-slate-300">Próximas Aulas</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
