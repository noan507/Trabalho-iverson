'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { ArrowLeft, Clock, User, FileText, School, Send, History } from 'lucide-react'

export default function ExitRequestsPage() {
  const [user, setUser] = useState<any>(null)
  const [requests, setRequests] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    studentName: '',
    className: '3º Ano D.S.',
    exitTime: '',
    validUntil: '',
    reason: ''
  })
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem('user')
    if (!userData) {
      router.push('/login?type=professor')
      return
    }
    
    const parsedUser = JSON.parse(userData)
    if (parsedUser.user_type !== 'professor') {
      router.push('/')
      return
    }
    
    setUser(parsedUser)
    loadRequests(parsedUser.id)
  }, [router])

  const loadRequests = async (professorId: string) => {
    try {
      const response = await fetch(`/api/exit-requests?professorId=${professorId}`)
      const data = await response.json()
      if (response.ok) {
        setRequests(data.data || [])
      }
    } catch (error) {
      console.error('Erro ao carregar solicitações:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setLoading(true)
    try {
      const response = await fetch('/api/exit-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: formData.studentName,
          classId: '1',
          professorId: user.id,
          exitTime: formData.exitTime,
          validUntil: formData.validUntil,
          reason: formData.reason
        })
      })

      if (response.ok) {
        setFormData({
          studentName: '',
          className: '3º Ano D.S.',
          exitTime: '',
          validUntil: '',
          reason: ''
        })
        loadRequests(user.id)
        alert('Solicitação criada com sucesso!')
      }
    } catch (error) {
      console.error('Erro ao criar solicitação:', error)
      alert('Erro ao criar solicitação')
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    const statusMap = {
      'pending': { variant: 'bg-yellow-600 hover:bg-yellow-700', text: 'Pendente' },
      'approved': { variant: 'bg-green-600 hover:bg-green-700', text: 'Aprovado' },
      'rejected': { variant: 'bg-red-600 hover:bg-red-700', text: 'Rejeitado' },
      'student_left': { variant: 'bg-blue-600 hover:bg-blue-700', text: 'Aluno Saiu' },
      'student_returned': { variant: 'bg-emerald-600 hover:bg-emerald-700', text: 'Retornou' },
      'overdue': { variant: 'bg-red-600 hover:bg-red-700', text: 'Atrasado' }
    }
    
    const config = statusMap[status as keyof typeof statusMap] || { variant: 'bg-slate-600 hover:bg-slate-700', text: status }
    return <Badge className={`${config.variant} text-white border-0`}>{config.text}</Badge>
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            onClick={() => router.back()}
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl shadow-lg">
            <School className="text-white h-8 w-8" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">Ficha de Saída</h1>
            <p className="text-slate-300">Sistema CESF - {user.full_name}</p>
          </div>
        </div>

        <Tabs defaultValue="form" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 bg-white/10 backdrop-blur-sm border-white/20">
            <TabsTrigger 
              value="form" 
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-slate-300 font-medium"
            >
              <FileText className="h-4 w-4 mr-2" />
              Nova Solicitação
            </TabsTrigger>
            <TabsTrigger 
              value="history" 
              className="data-[state=active]:bg-blue-600 data-[state=active]:text-white text-slate-300 font-medium"
            >
              <History className="h-4 w-4 mr-2" />
              Histórico
            </TabsTrigger>
          </TabsList>

          <TabsContent value="form">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Send className="h-5 w-5" />
                  Criar Nova Solicitação de Saída
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="className" className="text-white font-medium">Turma</Label>
                      <Input
                        id="className"
                        value={formData.className}
                        onChange={(e) => setFormData({...formData, className: e.target.value})}
                        className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="professorName" className="text-white font-medium">Professor Responsável</Label>
                      <Input
                        id="professorName"
                        value={user.full_name}
                        className="bg-white/5 border-white/10 text-slate-300 backdrop-blur-sm"
                        disabled
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="studentName" className="text-white font-medium">Nome do Aluno</Label>
                    <Input
                      id="studentName"
                      value={formData.studentName}
                      onChange={(e) => setFormData({...formData, studentName: e.target.value})}
                      className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm"
                      placeholder="Digite o nome completo do aluno"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="exitTime" className="text-white font-medium">Horário de Saída</Label>
                      <Input
                        id="exitTime"
                        type="time"
                        value={formData.exitTime}
                        onChange={(e) => setFormData({...formData, exitTime: e.target.value})}
                        className="bg-white/10 border-white/20 text-white focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm"
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="validUntil" className="text-white font-medium">Válido Até</Label>
                      <Input
                        id="validUntil"
                        type="time"
                        value={formData.validUntil}
                        onChange={(e) => setFormData({...formData, validUntil: e.target.value})}
                        className="bg-white/10 border-white/20 text-white focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="reason" className="text-white font-medium">Motivo da Saída</Label>
                    <Textarea
                      id="reason"
                      value={formData.reason}
                      onChange={(e) => setFormData({...formData, reason: e.target.value})}
                      className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm min-h-[100px]"
                      placeholder="Descreva o motivo da saída do aluno..."
                      rows={4}
                      required
                    />
                  </div>

                  <Button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white py-6 text-lg font-semibold transition-all duration-300 shadow-lg"
                  >
                    <Send className="mr-2 h-5 w-5" />
                    {loading ? 'Enviando Solicitação...' : 'Solicitar Saída'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history">
            <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <History className="h-5 w-5" />
                  Histórico de Solicitações
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-4">
                  {requests.length === 0 ? (
                    <Alert className="bg-blue-500/20 border-blue-500/30 text-blue-100 backdrop-blur-sm">
                      <AlertDescription className="flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        Nenhuma solicitação encontrada. Crie sua primeira solicitação na aba anterior.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    requests.map((request) => (
                      <div
                        key={request.id}
                        className="bg-white/5 backdrop-blur-sm rounded-lg p-6 border border-white/10 hover:bg-white/10 transition-all duration-200"
                      >
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3 text-white">
                            <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                              <User className="h-5 w-5" />
                            </div>
                            <div>
                              <h3 className="font-semibold text-lg">{request.student_name}</h3>
                              <p className="text-slate-300 text-sm">Turma: {request.classes?.name || 'N/A'}</p>
                            </div>
                          </div>
                          {getStatusBadge(request.status)}
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-slate-300 text-sm mb-4">
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-blue-400" />
                            <span><strong>Saída:</strong> {request.exit_time}</span>
                          </div>
                          {request.valid_until && (
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4 text-green-400" />
                              <span><strong>Válido até:</strong> {request.valid_until}</span>
                            </div>
                          )}
                        </div>
                        
                        {request.reason && (
                          <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                            <p className="text-white text-sm">
                              <strong className="text-blue-400">Motivo:</strong> {request.reason}
                            </p>
                          </div>
                        )}
                        
                        <div className="mt-4 pt-4 border-t border-white/10">
                          <p className="text-slate-400 text-xs">
                            Criado em: {new Date(request.created_at).toLocaleString('pt-BR')}
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
