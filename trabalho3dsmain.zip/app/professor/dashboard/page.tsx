'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { FileText, Clock, LogOut, School, Timer } from 'lucide-react'

export default function ProfessorDashboard() {
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem('user')
    if (!userData) {
      router.push('/login?type=professor')
      return
    }
    
    const parsedUser = JSON.parse(userData)
    if (parsedUser.user_type !== 'professor') {
      router.push('/')
      return
    }
    
    setUser(parsedUser)
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem('user')
    router.push('/')
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
      <div className="max-w-md mx-auto">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl shadow-lg mb-6">
            <School className="text-white h-12 w-12" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">
            Sistema <span className="text-blue-400">CESF</span>
          </h1>
          <p className="text-slate-300 text-lg">Controle de Saída de Alunos</p>
          <div className="mt-4 p-4 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20">
            <p className="text-white font-medium">Bem-vindo, {user.full_name}</p>
            <p className="text-slate-300 text-sm">{user.area}</p>
          </div>
        </div>

        <div className="space-y-4">
          <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl">
            <CardContent className="p-6 space-y-4">
              <Button
                onClick={() => router.push('/professor/exit-requests')}
                className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white py-6 text-lg font-semibold transition-all duration-300 hover:scale-105 shadow-lg"
              >
                <FileText className="mr-3 h-6 w-6" />
                Ficha de Saída e Histórico
              </Button>
              
              <Button
                onClick={() => router.push('/professor/schedule')}
                className="w-full bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-700 hover:to-emerald-800 text-white py-6 text-lg font-semibold transition-all duration-300 hover:scale-105 shadow-lg"
              >
                <Clock className="mr-3 h-6 w-6" />
                Aulas de Hoje
              </Button>

              <Button
                onClick={() => router.push('/professor/bathroom')}
                className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-6 text-lg font-semibold transition-all duration-300 hover:scale-105 shadow-lg"
              >
                <Timer className="mr-3 h-6 w-6" />
                Controle de Banheiro
              </Button>
              
              <div className="pt-4 border-t border-white/20">
                <Button
                  onClick={handleLogout}
                  variant="outline"
                  className="w-full bg-white/10 text-white border-white/30 hover:bg-white/20 py-6 text-lg font-semibold transition-all duration-300 hover:scale-105 backdrop-blur-sm"
                >
                  <LogOut className="mr-3 h-6 w-6" />
                  Sair do Sistema
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
