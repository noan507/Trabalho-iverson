'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { ArrowLeft, Clock, User, Timer, School, Send, AlertTriangle, CheckCircle } from 'lucide-react'

export default function BathroomPage() {
  const [user, setUser] = useState<any>(null)
  const [requests, setRequests] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    studentName: '',
    className: '3º Ano D.S.'
  })
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem('user')
    if (!userData) {
      router.push('/login?type=professor')
      return
    }
    
    const parsedUser = JSON.parse(userData)
    if (parsedUser.user_type !== 'professor') {
      router.push('/')
      return
    }
    
    setUser(parsedUser)
    loadRequests(parsedUser.id)
  }, [router])

  const loadRequests = async (professorId: string) => {
    try {
      const response = await fetch(`/api/bathroom-requests?professorId=${professorId}`)
      const data = await response.json()
      if (response.ok) {
        setRequests(data.data || [])
      }
    } catch (error) {
      console.error('Erro ao carregar solicitações:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setLoading(true)
    try {
      const response = await fetch('/api/bathroom-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName: formData.studentName,
          classId: '1',
          professorId: user.id
        })
      })

      if (response.ok) {
        setFormData({
          studentName: '',
          className: '3º Ano D.S.'
        })
        loadRequests(user.id)
        alert('Solicitação de banheiro criada!')
      }
    } catch (error) {
      console.error('Erro ao criar solicitação:', error)
      alert('Erro ao criar solicitação')
    } finally {
      setLoading(false)
    }
  }

  const handleStatusUpdate = async (id: string, status: string) => {
    try {
      const response = await fetch('/api/bathroom-requests', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id,
          status,
          returnTime: status === 'student_returned' ? new Date().toISOString() : null
        })
      })

      if (response.ok) {
        loadRequests(user.id)
        if (status === 'student_returned') {
          alert('Retorno confirmado!')
        }
      }
    } catch (error) {
      console.error('Erro ao atualizar status:', error)
    }
  }

  const getStatusBadge = (status: string) => {
    const statusMap = {
      'pending': { variant: 'bg-yellow-600 hover:bg-yellow-700', text: 'Aguardando', icon: Clock },
      'student_left': { variant: 'bg-blue-600 hover:bg-blue-700', text: 'No Banheiro', icon: Timer },
      'student_returned': { variant: 'bg-green-600 hover:bg-green-700', text: 'Retornou', icon: CheckCircle },
      'overdue': { variant: 'bg-red-600 hover:bg-red-700', text: 'Atrasado', icon: AlertTriangle }
    }
    
    const config = statusMap[status as keyof typeof statusMap] || { variant: 'bg-slate-600 hover:bg-slate-700', text: status, icon: Clock }
    const IconComponent = config.icon
    
    return (
      <Badge className={`${config.variant} text-white border-0 flex items-center gap-1`}>
        <IconComponent className="h-3 w-3" />
        {config.text}
      </Badge>
    )
  }

  const getTimeElapsed = (exitTime: string) => {
    const exit = new Date(exitTime)
    const now = new Date()
    const diffMinutes = Math.floor((now.getTime() - exit.getTime()) / (1000 * 60))
    return diffMinutes
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button
            onClick={() => router.back()}
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-purple-600 to-purple-800 rounded-xl shadow-lg">
            <Timer className="text-white h-8 w-8" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-white">Controle de Banheiro</h1>
            <p className="text-slate-300">Sistema CESF - {user.full_name}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Formulário */}
          <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Send className="h-5 w-5" />
                Nova Solicitação de Banheiro
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="studentName" className="text-white font-medium">Nome do Aluno</Label>
                  <Input
                    id="studentName"
                    value={formData.studentName}
                    onChange={(e) => setFormData({...formData, studentName: e.target.value})}
                    className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 focus:border-purple-400 focus:ring-purple-400/20 backdrop-blur-sm"
                    placeholder="Digite o nome completo do aluno"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="className" className="text-white font-medium">Turma</Label>
                  <Input
                    id="className"
                    value={formData.className}
                    onChange={(e) => setFormData({...formData, className: e.target.value})}
                    className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 focus:border-purple-400 focus:ring-purple-400/20 backdrop-blur-sm"
                    required
                  />
                </div>

                <div className="bg-purple-500/20 border border-purple-500/30 rounded-lg p-4">
                  <div className="flex items-center gap-2 text-purple-200 text-sm">
                    <Timer className="h-4 w-4" />
                    <span><strong>Tempo limite:</strong> 10 minutos</span>
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-6 text-lg font-semibold transition-all duration-300 shadow-lg"
                >
                  <Send className="mr-2 h-5 w-5" />
                  {loading ? 'Enviando...' : 'Solicitar Saída para Banheiro'}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Lista de Solicitações */}
          <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Timer className="h-5 w-5" />
                Solicitações Ativas ({requests.length})
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4 max-h-[600px] overflow-y-auto">
                {requests.length === 0 ? (
                  <Alert className="bg-blue-500/20 border-blue-500/30 text-blue-100 backdrop-blur-sm">
                    <Timer className="h-4 w-4" />
                    <AlertDescription>
                      Nenhuma solicitação ativa no momento.
                    </AlertDescription>
                  </Alert>
                ) : (
                  requests.map((request) => {
                    const timeElapsed = getTimeElapsed(request.exit_time)
                    const isOverdue = timeElapsed > request.max_duration_minutes
                    
                    return (
                      <div
                        key={request.id}
                        className={`rounded-lg p-6 border transition-all duration-200 ${
                          isOverdue && request.status === 'student_left' 
                            ? 'bg-red-500/20 border-red-500/30 hover:bg-red-500/30' 
                            : 'bg-white/5 border-white/10 hover:bg-white/10'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-3 text-white">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                              isOverdue && request.status === 'student_left' ? 'bg-red-600' : 'bg-purple-600'
                            }`}>
                              <User className="h-5 w-5" />
                            </div>
                            <div>
                              <h3 className="font-semibold text-lg">{request.student_name}</h3>
                              <p className="text-slate-300 text-sm">Turma: {request.classes?.name || formData.className}</p>
                            </div>
                          </div>
                          {getStatusBadge(isOverdue && request.status === 'student_left' ? 'overdue' : request.status)}
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 text-slate-300 text-sm mb-4">
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-blue-400" />
                            <span><strong>Tempo:</strong> {timeElapsed} min</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Timer className="h-4 w-4 text-purple-400" />
                            <span><strong>Limite:</strong> {request.max_duration_minutes} min</span>
                          </div>
                        </div>

                        {request.status === 'student_left' && (
                          <Button
                            onClick={() => handleStatusUpdate(request.id, 'student_returned')}
                            size="sm"
                            className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white transition-all duration-200"
                          >
                            <CheckCircle className="mr-2 h-4 w-4" />
                            Confirmar Retorno
                          </Button>
                        )}

                        {isOverdue && request.status === 'student_left' && (
                          <Alert className="mt-4 bg-red-500/20 border-red-500/30 text-red-100 backdrop-blur-sm">
                            <AlertTriangle className="h-4 w-4" />
                            <AlertDescription>
                              <strong>Atenção!</strong> Aluno está atrasado! Tempo limite de {request.max_duration_minutes} minutos foi excedido.
                            </AlertDescription>
                          </Alert>
                        )}

                        <div className="mt-4 pt-4 border-t border-white/10">
                          <p className="text-slate-400 text-xs">
                            Saída: {new Date(request.exit_time).toLocaleString('pt-BR')}
                          </p>
                        </div>
                      </div>
                    )
                  })
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
