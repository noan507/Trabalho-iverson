'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { School, RefreshCw, ArrowLeft } from 'lucide-react'
import { useRouter } from 'next/navigation'

export default function DebugPage() {
  const [users, setUsers] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  const loadUsers = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/debug/users')
      const data = await response.json()
      if (response.ok) {
        setUsers(data.users || [])
      }
    } catch (error) {
      console.error('Erro ao carregar usuários:', error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadUsers()
  }, [])

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'professor': return 'bg-blue-600 hover:bg-blue-700'
      case 'coordenador': return 'bg-emerald-600 hover:bg-emerald-700'
      case 'fiscal': return 'bg-purple-600 hover:bg-purple-700'
      default: return 'bg-slate-600 hover:bg-slate-700'
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'professor': return 'Professor'
      case 'coordenador': return 'Coordenador'
      case 'fiscal': return 'Fiscal'
      default: return type
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <Button
            onClick={() => router.push('/')}
            variant="ghost"
            size="sm"
            className="absolute top-4 left-4 text-white hover:bg-white/10"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          
          <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl shadow-lg mb-6">
            <School className="text-white h-12 w-12" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">
            Debug - Usuários Cadastrados
          </h1>
          <p className="text-slate-300 text-lg">
            Total de usuários: {users.length}
          </p>
        </div>

        <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-white flex items-center justify-between">
              <span>Usuários no Sistema</span>
              <Button 
                onClick={loadUsers} 
                size="sm" 
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Atualizar
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
                <p className="text-white">Carregando usuários...</p>
              </div>
            ) : users.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-white text-lg">Nenhum usuário encontrado</p>
                <p className="text-slate-400 text-sm mt-2">Registre-se para aparecer aqui</p>
              </div>
            ) : (
              <div className="space-y-4">
                {users.map((user) => (
                  <div
                    key={user.id}
                    className="bg-white/5 backdrop-blur-sm rounded-lg p-6 border border-white/10 hover:bg-white/10 transition-all duration-200"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="text-white">
                        <h3 className="font-semibold text-lg">{user.full_name}</h3>
                        <p className="text-slate-300">{user.email}</p>
                      </div>
                      <Badge className={`${getTypeColor(user.user_type)} text-white border-0`}>
                        {getTypeLabel(user.user_type)}
                      </Badge>
                    </div>
                    {user.area && (
                      <p className="text-slate-300 text-sm mb-2">
                        <strong className="text-white">Área:</strong> {user.area}
                      </p>
                    )}
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span>ID: {user.id}</span>
                      <span className={`px-2 py-1 rounded ${user.is_active ? 'bg-green-600/20 text-green-300' : 'bg-red-600/20 text-red-300'}`}>
                        {user.is_active ? 'Ativo' : 'Inativo'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
