'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { School, ArrowLeft, UserPlus } from 'lucide-react'

export default function RegisterPage() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
    userType: '',
    area: ''
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  
  const router = useRouter()

  // Áreas de atuação por tipo de usuário
  const areaOptions = {
    coordenador: [
      'Pedagógico',
      'Disciplinar',
      'Administrativo',
      'Orientação Educacional',
      'Supervisão Escolar',
      'Coordenação de Área',
      'Projetos Especiais',
      'Inclusão e Acessibilidade'
    ],
    fiscal: [
      'Disciplinar',
      'Monitor de Pátio',
      'Controle de Entrada/Saída',
      'Biblioteca',
      'Laboratórios',
      'Refeitório',
      'Transporte Escolar',
      'Eventos e Atividades',
      'Segurança Escolar'
    ]
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setSuccess('')

    if (!formData.fullName || !formData.email || !formData.password || !formData.userType) {
      setError('Todos os campos obrigatórios devem ser preenchidos')
      setLoading(false)
      return
    }

    if ((formData.userType === 'coordenador' || formData.userType === 'fiscal') && !formData.area) {
      setError('Área de atuação é obrigatória para coordenadores e fiscais')
      setLoading(false)
      return
    }

    if (formData.password !== formData.confirmPassword) {
      setError('As senhas não coincidem')
      setLoading(false)
      return
    }

    if (formData.password.length < 3) {
      setError('Senha deve ter pelo menos 3 caracteres')
      setLoading(false)
      return
    }

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      })

      const data = await response.json()

      if (response.ok) {
        setSuccess('Conta criada com sucesso! Redirecionando...')
        setTimeout(() => {
          router.push('/login?type=' + formData.userType)
        }, 2000)
      } else {
        setError(data.error || 'Erro ao criar conta')
      }
    } catch (error) {
      setError('Erro de conexão com o servidor')
    } finally {
      setLoading(false)
    }
  }

  // Reset área quando muda o tipo de usuário
  const handleUserTypeChange = (value: string) => {
    setFormData({
      ...formData, 
      userType: value,
      area: '' // Reset área quando muda tipo
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Button
            onClick={() => router.push('/')}
            variant="ghost"
            size="sm"
            className="absolute top-4 left-4 text-white hover:bg-white/10"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          
          <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl shadow-lg mb-6">
            <School className="text-white h-12 w-12" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2 flex items-center justify-center gap-3">
            <UserPlus className="h-8 w-8" />
            Criar Conta
          </h1>
          <p className="text-slate-300">Sistema CESF</p>
        </div>

        <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl">
          <CardContent className="p-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              {error && (
                <Alert className="bg-red-500/20 border-red-500/30 text-red-100 backdrop-blur-sm">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {success && (
                <Alert className="bg-green-500/20 border-green-500/30 text-green-100 backdrop-blur-sm">
                  <AlertDescription>{success}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="fullName" className="text-white font-medium">Nome Completo</Label>
                <Input
                  id="fullName"
                  type="text"
                  placeholder="Seu nome completo"
                  value={formData.fullName}
                  onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                  className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-white font-medium">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seu.email@cesf.edu.br"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-white font-medium">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Digite uma senha"
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-white font-medium">Confirmar Senha</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="Digite a senha novamente"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
                  className="bg-white/10 border-white/20 text-white placeholder:text-slate-400 focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="userType" className="text-white font-medium">Tipo de Usuário</Label>
                <Select onValueChange={handleUserTypeChange} value={formData.userType}>
                  <SelectTrigger className="bg-white/10 border-white/20 text-white focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm">
                    <SelectValue placeholder="Selecione o tipo de usuário" className="text-white" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-slate-700 backdrop-blur-lg">
                    <SelectItem value="professor" className="text-white hover:bg-slate-700 focus:bg-slate-700">
                      👨‍🏫 Professor
                    </SelectItem>
                    <SelectItem value="coordenador" className="text-white hover:bg-slate-700 focus:bg-slate-700">
                      👥 Coordenador
                    </SelectItem>
                    <SelectItem value="fiscal" className="text-white hover:bg-slate-700 focus:bg-slate-700">
                      🛡️ Fiscal
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {(formData.userType === 'coordenador' || formData.userType === 'fiscal') && (
                <div className="space-y-2">
                  <Label htmlFor="area" className="text-white font-medium">
                    Área de Atuação
                    <span className="text-red-400 ml-1">*</span>
                  </Label>
                  <Select onValueChange={(value) => setFormData({...formData, area: value})} value={formData.area}>
                    <SelectTrigger className="bg-white/10 border-white/20 text-white focus:border-blue-400 focus:ring-blue-400/20 backdrop-blur-sm">
                      <SelectValue placeholder={`Selecione a área de ${formData.userType}`} className="text-white" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-700 backdrop-blur-lg max-h-60">
                      {areaOptions[formData.userType as keyof typeof areaOptions]?.map((area) => (
                        <SelectItem 
                          key={area} 
                          value={area} 
                          className="text-white hover:bg-slate-700 focus:bg-slate-700"
                        >
                          {area}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  {/* Informação sobre as áreas */}
                  <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-3 mt-2">
                    <p className="text-blue-200 text-sm">
                      <strong>💡 Dica:</strong> Selecione a área que melhor descreve sua função na escola.
                    </p>
                  </div>
                </div>
              )}

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white py-6 text-lg font-semibold transition-all duration-300 shadow-lg"
              >
                {loading ? 'Criando Conta...' : 'Criar Conta'}
              </Button>

              {/* Informações sobre os tipos de usuário */}
              <div className="bg-white/5 backdrop-blur-sm rounded-lg p-4 border border-white/10">
                <h3 className="text-white font-medium mb-2">ℹ️ Tipos de Usuário:</h3>
                <div className="space-y-2 text-sm text-slate-300">
                  <div><strong className="text-blue-400">Professor:</strong> Acesso a fichas de saída e controle de banheiro</div>
                  <div><strong className="text-emerald-400">Coordenador:</strong> Monitoramento de alunos e aprovação de saídas</div>
                  <div><strong className="text-purple-400">Fiscal:</strong> Controle disciplinar e monitoramento de banheiros</div>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
