-- =====================================================
-- DADOS INICIAIS DO SISTEMA
-- =====================================================

-- Inserir tipos de usuário
INSERT INTO user_types (type_name, display_name, description, permissions) VALUES
('admin', 'Administrador', 'Acesso completo ao sistema', '{"all": true}'),
('coordenador', 'Coordenador', 'Coordenação pedagógica e disciplinar', '{"approve_requests": true, "view_reports": true}'),
('professor', 'Professor', 'Criação de solicitações de saída', '{"create_requests": true}'),
('fiscal', 'Fiscal', 'Monitoramento e controle disciplinar', '{"monitor_students": true, "bathroom_control": true}')
ON CONFLICT (type_name) DO NOTHING;

-- Inserir áreas de atuação para coordenadores
INSERT INTO areas (area_name, area_code, user_type, description, color_code, icon_name, sort_order) VALUES
('Pedagógico', 'PED', 'coordenador', 'Coordenação pedagógica geral', '#10B981', 'book-open', 1),
('Disciplinar', 'DIS', 'coordenador', 'Controle disciplinar e comportamental', '#EF4444', 'shield', 2),
('Administrativo', 'ADM', 'coordenador', 'Gestão administrativa escolar', '#3B82F6', 'briefcase', 3),
('Orientação Educacional', 'ORI', 'coordenador', 'Orientação e acompanhamento de alunos', '#8B5CF6', 'heart', 4),
('Supervisão Escolar', 'SUP', 'coordenador', 'Supervisão geral das atividades', '#F59E0B', 'eye', 5),
('Coordenação de Área', 'CAR', 'coordenador', 'Coordenação por área de conhecimento', '#06B6D4', 'layers', 6),
('Projetos Especiais', 'PRO', 'coordenador', 'Gestão de projetos específicos', '#EC4899', 'star', 7),
('Inclusão e Acessibilidade', 'INC', 'coordenador', 'Educação inclusiva e acessibilidade', '#84CC16', 'users', 8)
ON CONFLICT (area_code) DO NOTHING;

-- Inserir áreas de atuação para fiscais
INSERT INTO areas (area_name, area_code, user_type, description, color_code, icon_name, sort_order) VALUES
('Disciplinar', 'DIS_F', 'fiscal', 'Controle disciplinar geral', '#EF4444', 'shield', 1),
('Monitor de Pátio', 'PAT', 'fiscal', 'Supervisão de pátio e recreio', '#10B981', 'eye', 2),
('Controle de Entrada/Saída', 'ENT', 'fiscal', 'Controle de portaria e acesso', '#3B82F6', 'door-open', 3),
('Biblioteca', 'BIB', 'fiscal', 'Supervisão da biblioteca', '#8B5CF6', 'book', 4),
('Laboratórios', 'LAB', 'fiscal', 'Controle de laboratórios', '#F59E0B', 'flask', 5),
('Refeitório', 'REF', 'fiscal', 'Supervisão do refeitório', '#06B6D4', 'utensils', 6),
('Transporte Escolar', 'TRA', 'fiscal', 'Controle de transporte', '#EC4899', 'bus', 7),
('Eventos e Atividades', 'EVE', 'fiscal', 'Supervisão de eventos', '#84CC16', 'calendar', 8),
('Segurança Escolar', 'SEG', 'fiscal', 'Segurança geral da escola', '#6B7280', 'lock', 9)
ON CONFLICT (area_code) DO NOTHING;

-- Inserir disciplinas
INSERT INTO subjects (name, code, description, color_code) VALUES
('Matemática', 'MAT', 'Disciplina de Matemática', '#3B82F6'),
('Português', 'POR', 'Língua Portuguesa', '#10B981'),
('História', 'HIS', 'História Geral e do Brasil', '#F59E0B'),
('Geografia', 'GEO', 'Geografia Física e Humana', '#06B6D4'),
('Ciências', 'CIE', 'Ciências Naturais', '#8B5CF6'),
('Inglês', 'ING', 'Língua Inglesa', '#EC4899'),
('Educação Física', 'EDF', 'Educação Física e Esportes', '#EF4444'),
('Artes', 'ART', 'Artes Visuais e Música', '#84CC16'),
('Ciência da Computação', 'CC', 'Programação e Informática', '#1F2937'),
('Design Gráfico', 'DG', 'Design e Criação Visual', '#F97316'),
('Física', 'FIS', 'Física Geral', '#6366F1'),
('Química', 'QUI', 'Química Geral', '#059669'),
('Biologia', 'BIO', 'Biologia e Ciências da Vida', '#DC2626'),
('Filosofia', 'FIL', 'Filosofia e Ética', '#7C3AED'),
('Sociologia', 'SOC', 'Sociologia e Cidadania', '#DB2777')
ON CONFLICT (code) DO NOTHING;

-- Inserir turmas
INSERT INTO classes (name, code, grade_level, academic_year, max_students, classroom) VALUES
('3º Ano D.S.', '3DS', 'Ensino Médio Técnico', 2024, 35, 'Sala 15'),
('2º Ano A', '2A', 'Ensino Médio', 2024, 40, 'Sala 08'),
('2º Ano B', '2B', 'Ensino Médio', 2024, 40, 'Sala 09'),
('1º Ano A', '1A', 'Ensino Médio', 2024, 42, 'Sala 05'),
('1º Ano B', '1B', 'Ensino Médio', 2024, 42, 'Sala 06'),
('3º Ano A', '3A', 'Ensino Médio', 2024, 38, 'Sala 12'),
('3º Ano B', '3B', 'Ensino Médio', 2024, 38, 'Sala 13')
ON CONFLICT (code) DO NOTHING;

-- Inserir usuários padrão (senhas são hash de 'password123')
INSERT INTO users (email, password_hash, full_name, user_type, area_id, phone, is_active) VALUES
-- Administrador
('admin@cesf.edu.br', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQ', 'Administrador do Sistema', 'admin', NULL, '+55 11 99999-0000', true),

-- Professores
('maria.silva@cesf.edu.br', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQ', 'Maria Silva Santos', 'professor', NULL, '+55 11 99999-0001', true),
('joao.santos@cesf.edu.br', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQ', 'João Santos Oliveira', 'professor', NULL, '+55 11 99999-0002', true),
('ana.costa@cesf.edu.br', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQ', 'Ana Costa Lima', 'professor', NULL, '+55 11 99999-0003', true),

-- Coordenadores
('carlos.oliveira@cesf.edu.br', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQ', 'Carlos Oliveira Mendes', 'coordenador', (SELECT id FROM areas WHERE area_code = 'PED'), '+55 11 99999-0004', true),
('lucia.ferreira@cesf.edu.br', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQ', 'Lúcia Ferreira Rocha', 'coordenador', (SELECT id FROM areas WHERE area_code = 'DIS'), '+55 11 99999-0005', true),

-- Fiscais
('pedro.almeida@cesf.edu.br', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQ', 'Pedro Almeida Silva', 'fiscal', (SELECT id FROM areas WHERE area_code = 'PAT'), '+55 11 99999-0006', true),
('mariana.souza@cesf.edu.br', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQ', 'Mariana Souza Lima', 'fiscal', (SELECT id FROM areas WHERE area_code = 'ENT'), '+55 11 99999-0007', true)

ON CONFLICT (email) DO NOTHING;

-- Inserir alguns horários de exemplo
INSERT INTO class_schedules (class_id, subject_id, professor_id, day_of_week, start_time, end_time, classroom, academic_year) 
SELECT 
    c.id,
    s.id,
    u.id,
    1, -- Segunda-feira
    '07:30'::time,
    '08:20'::time,
    'Sala 15',
    2024
FROM classes c, subjects s, users u 
WHERE c.code = '3DS' 
  AND s.code = 'MAT' 
  AND u.email = 'maria.silva@cesf.edu.br'
  AND NOT EXISTS (
    SELECT 1 FROM class_schedules cs 
    WHERE cs.class_id = c.id AND cs.subject_id = s.id AND cs.professor_id = u.id
  );
