-- =====================================================
-- ÍNDICES OTIMIZADOS PARA PERFORMANCE
-- =====================================================

-- Índices para tabela users
CREATE INDEX CONCURRENTLY idx_users_email_active ON users(email) WHERE is_active = true;
CREATE INDEX CONCURRENTLY idx_users_type_area ON users(user_type, area_id) WHERE is_active = true;
CREATE INDEX CONCURRENTLY idx_users_last_login ON users(last_login DESC) WHERE is_active = true;
CREATE INDEX CONCURRENTLY idx_users_created_at ON users(created_at DESC);
CREATE INDEX CONCURRENTLY idx_users_full_name_gin ON users USING gin(to_tsvector('portuguese', full_name));

-- Índices para tabela areas
CREATE INDEX CONCURRENTLY idx_areas_user_type_active ON areas(user_type) WHERE is_active = true;
CREATE INDEX CONCURRENTLY idx_areas_sort_order ON areas(sort_order, area_name);

-- Índices para tabela classes
CREATE INDEX CONCURRENTLY idx_classes_academic_year_active ON classes(academic_year) WHERE is_active = true;
CREATE INDEX CONCURRENTLY idx_classes_code_active ON classes(code) WHERE is_active = true;
CREATE INDEX CONCURRENTLY idx_classes_name_gin ON classes USING gin(to_tsvector('portuguese', name));

-- Índices para tabela subjects
CREATE INDEX CONCURRENTLY idx_subjects_code_active ON subjects(code) WHERE is_active = true;
CREATE INDEX CONCURRENTLY idx_subjects_name_gin ON subjects USING gin(to_tsvector('portuguese', name));

-- Índices para tabela class_schedules
CREATE INDEX CONCURRENTLY idx_schedules_professor_day ON class_schedules(professor_id, day_of_week, start_time);
CREATE INDEX CONCURRENTLY idx_schedules_class_day ON class_schedules(class_id, day_of_week, start_time);
CREATE INDEX CONCURRENTLY idx_schedules_time_range ON class_schedules(day_of_week, start_time, end_time);
CREATE INDEX CONCURRENTLY idx_schedules_academic_year ON class_schedules(academic_year, semester) WHERE is_active = true;

-- Índices para tabela exit_requests
CREATE INDEX CONCURRENTLY idx_exit_requests_status_date ON exit_requests(status, exit_date DESC);
CREATE INDEX CONCURRENTLY idx_exit_requests_professor_date ON exit_requests(professor_id, exit_date DESC);
CREATE INDEX CONCURRENTLY idx_exit_requests_student_name ON exit_requests(student_name, exit_date DESC);
CREATE INDEX CONCURRENTLY idx_exit_requests_class_date ON exit_requests(class_id, exit_date DESC);
CREATE INDEX CONCURRENTLY idx_exit_requests_pending ON exit_requests(created_at DESC) WHERE status = 'pending';
CREATE INDEX CONCURRENTLY idx_exit_requests_overdue ON exit_requests(return_deadline) WHERE status IN ('approved', 'student_left');
CREATE INDEX CONCURRENTLY idx_exit_requests_number ON exit_requests(request_number);
CREATE INDEX CONCURRENTLY idx_exit_requests_priority ON exit_requests(priority DESC, created_at DESC);

-- Índices para tabela bathroom_requests
CREATE INDEX CONCURRENTLY idx_bathroom_requests_status_time ON bathroom_requests(status, exit_time DESC);
CREATE INDEX CONCURRENTLY idx_bathroom_requests_professor_time ON bathroom_requests(professor_id, exit_time DESC);
CREATE INDEX CONCURRENTLY idx_bathroom_requests_student_time ON bathroom_requests(student_name, exit_time DESC);
CREATE INDEX CONCURRENTLY idx_bathroom_requests_active ON bathroom_requests(exit_time DESC) WHERE status IN ('pending', 'student_left');
CREATE INDEX CONCURRENTLY idx_bathroom_requests_overdue ON bathroom_requests(exit_time, max_duration_minutes) WHERE status = 'student_left';
CREATE INDEX CONCURRENTLY idx_bathroom_requests_number ON bathroom_requests(request_number);

-- Índices para tabela activity_logs
CREATE INDEX CONCURRENTLY idx_activity_logs_user_time ON activity_logs(user_id, created_at DESC);
CREATE INDEX CONCURRENTLY idx_activity_logs_type_time ON activity_logs(activity_type, created_at DESC);
CREATE INDEX CONCURRENTLY idx_activity_logs_entity ON activity_logs(entity_type, entity_id, created_at DESC);
CREATE INDEX CONCURRENTLY idx_activity_logs_session ON activity_logs(session_id, created_at DESC);
CREATE INDEX CONCURRENTLY idx_activity_logs_ip ON activity_logs(ip_address, created_at DESC);

-- Índices para tabela audit_log
CREATE INDEX CONCURRENTLY idx_audit_log_table_record ON audit_log(table_name, record_id, created_at DESC);
CREATE INDEX CONCURRENTLY idx_audit_log_user_time ON audit_log(user_id, created_at DESC);
CREATE INDEX CONCURRENTLY idx_audit_log_action_time ON audit_log(action, created_at DESC);

-- Índices compostos para consultas complexas
CREATE INDEX CONCURRENTLY idx_exit_requests_complex ON exit_requests(professor_id, status, exit_date DESC, priority DESC);
CREATE INDEX CONCURRENTLY idx_bathroom_requests_complex ON bathroom_requests(professor_id, status, exit_time DESC);

-- Índices parciais para otimização de consultas específicas
CREATE INDEX CONCURRENTLY idx_users_failed_logins ON users(failed_login_attempts, account_locked_until) WHERE failed_login_attempts > 0;
CREATE INDEX CONCURRENTLY idx_users_must_change_password ON users(id) WHERE must_change_password = true;
