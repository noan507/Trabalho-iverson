-- =====================================================
-- TABELAS DE SOLICITAÇÕES
-- =====================================================

-- Tabela de solicitações de saída (melhorada)
CREATE TABLE exit_requests (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    request_number VARCHAR(20) UNIQUE NOT NULL, -- Número sequencial para identificação
    student_name VARCHAR(255) NOT NULL,
    student_id VARCHAR(50), -- ID do aluno se houver sistema de alunos
    class_id UUID REFERENCES classes(id),
    professor_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Horários e tempos
    exit_time TIME NOT NULL,
    exit_date DATE DEFAULT CURRENT_DATE,
    valid_until TIME,
    estimated_return TIME,
    actual_exit_time TIMESTAMP WITH TIME ZONE,
    actual_return_time TIMESTAMP WITH TIME ZONE,
    
    -- Detalhes da solicitação
    reason TEXT NOT NULL,
    destination VARCHAR(255),
    emergency_contact VARCHAR(100),
    emergency_phone VARCHAR(20),
    
    -- Status e aprovação
    status request_status_enum DEFAULT 'pending',
    priority INTEGER DEFAULT 1 CHECK (priority BETWEEN 1 AND 5), -- 1=baixa, 5=emergência
    approved_by UUID REFERENCES users(id),
    approved_at TIMESTAMP WITH TIME ZONE,
    approval_notes TEXT,
    
    -- Controle de retorno
    return_deadline TIMESTAMP WITH TIME ZONE,
    return_reminder_sent BOOLEAN DEFAULT false,
    overdue_alert_sent BOOLEAN DEFAULT false,
    
    -- Metadados
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    updated_by UUID REFERENCES users(id),
    
    -- Constraints
    CONSTRAINT valid_exit_time CHECK (
        exit_time BETWEEN '06:00:00' AND '22:00:00'
    ),
    CONSTRAINT valid_return_time CHECK (
        valid_until IS NULL OR valid_until > exit_time
    ),
    CONSTRAINT reason_not_empty CHECK (length(trim(reason)) >= 10),
    CONSTRAINT student_name_not_empty CHECK (length(trim(student_name)) > 0),
    CONSTRAINT valid_priority CHECK (priority BETWEEN 1 AND 5)
);

-- Tabela de solicitações de banheiro (melhorada)
CREATE TABLE bathroom_requests (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    request_number VARCHAR(20) UNIQUE NOT NULL,
    student_name VARCHAR(255) NOT NULL,
    student_id VARCHAR(50),
    class_id UUID REFERENCES classes(id),
    professor_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Controle de tempo
    exit_time TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    return_time TIMESTAMP WITH TIME ZONE,
    max_duration_minutes INTEGER DEFAULT 10 CHECK (max_duration_minutes BETWEEN 5 AND 30),
    
    -- Status e controle
    status bathroom_status_enum DEFAULT 'pending',
    bathroom_location VARCHAR(100) DEFAULT 'Principal',
    
    -- Alertas e notificações
    five_minute_alert_sent BOOLEAN DEFAULT false,
    overdue_alert_sent BOOLEAN DEFAULT false,
    
    -- Metadados
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    updated_by UUID REFERENCES users(id),
    
    -- Constraints
    CONSTRAINT student_name_bathroom_not_empty CHECK (length(trim(student_name)) > 0),
    CONSTRAINT valid_duration CHECK (max_duration_minutes BETWEEN 5 AND 30)
);

-- Tabela de log de auditoria (completa)
CREATE TABLE audit_log (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL,
    record_id UUID,
    action VARCHAR(20) NOT NULL CHECK (action IN ('INSERT', 'UPDATE', 'DELETE')),
    old_values JSONB,
    new_values JSONB,
    changed_fields TEXT[],
    user_id UUID REFERENCES users(id),
    ip_address INET,
    user_agent TEXT,
    session_id VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Índices para performance
    CONSTRAINT valid_action CHECK (action IN ('INSERT', 'UPDATE', 'DELETE'))
);

-- Tabela de logs de atividades (melhorada)
CREATE TABLE activity_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    activity_type activity_type_enum NOT NULL,
    description TEXT NOT NULL,
    entity_type VARCHAR(100),
    entity_id UUID,
    metadata JSONB DEFAULT '{}',
    
    -- Informações de contexto
    ip_address INET,
    user_agent TEXT,
    session_id VARCHAR(255),
    request_id VARCHAR(100), -- Para rastreamento de requests
    
    -- Geolocalização (opcional)
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    
    -- Timing
    duration_ms INTEGER, -- Duração da operação em ms
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Constraints
    CONSTRAINT description_not_empty CHECK (length(trim(description)) > 0),
    CONSTRAINT valid_coordinates CHECK (
        (latitude IS NULL AND longitude IS NULL) OR 
        (latitude BETWEEN -90 AND 90 AND longitude BETWEEN -180 AND 180)
    )
);
