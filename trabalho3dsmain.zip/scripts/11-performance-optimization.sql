-- =====================================================
-- OTIMIZAÇÕES DE PERFORMANCE
-- =====================================================

-- Configurações de performance para PostgreSQL
-- (Estas configurações devem ser aplicadas no postgresql.conf)

-- Análise de estatísticas automática
ALTER SYSTEM SET track_activities = on;
ALTER SYSTEM SET track_counts = on;
ALTER SYSTEM SET track_io_timing = on;
ALTER SYSTEM SET track_functions = 'all';

-- Configurações de memória (ajustar conforme hardware)
-- ALTER SYSTEM SET shared_buffers = '256MB';
-- ALTER SYSTEM SET effective_cache_size = '1GB';
-- ALTER SYSTEM SET work_mem = '4MB';
-- ALTER SYSTEM SET maintenance_work_mem = '64MB';

-- Configurações de checkpoint
-- ALTER SYSTEM SET checkpoint_completion_target = 0.9;
-- ALTER SYSTEM SET wal_buffers = '16MB';

-- Função para análise de performance de queries
CREATE OR REPLACE FUNCTION analyze_query_performance()
RETURNS TABLE(
    query TEXT,
    calls BIGINT,
    total_time DOUBLE PRECISION,
    mean_time DOUBLE PRECISION,
    rows BIGINT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        pg_stat_statements.query,
        pg_stat_statements.calls,
        pg_stat_statements.total_exec_time,
        pg_stat_statements.mean_exec_time,
        pg_stat_statements.rows
    FROM pg_stat_statements
    WHERE pg_stat_statements.calls > 10
    ORDER BY pg_stat_statements.total_exec_time DESC
    LIMIT 20;
EXCEPTION
    WHEN undefined_table THEN
        RAISE NOTICE 'pg_stat_statements extension not available';
        RETURN;
END;
$$ LANGUAGE plpgsql;

-- Função para otimização automática de índices
CREATE OR REPLACE FUNCTION suggest_missing_indexes()
RETURNS TABLE(
    table_name TEXT,
    column_names TEXT,
    reason TEXT
) AS $$
BEGIN
    -- Esta é uma versão simplificada
    -- Em produção, seria mais complexa baseada em pg_stat_user_tables
    
    RETURN QUERY
    SELECT 
        'exit_requests'::TEXT,
        'student_name, exit_date'::TEXT,
        'Frequent searches by student name and date'::TEXT
    WHERE NOT EXISTS (
        SELECT 1 FROM pg_indexes 
        WHERE tablename = 'exit_requests' 
        AND indexname LIKE '%student_name%'
    );
    
    RETURN QUERY
    SELECT 
        'bathroom_requests'::TEXT,
        'student_name, exit_time'::TEXT,
        'Frequent searches by student name and time'::TEXT
    WHERE NOT EXISTS (
        SELECT 1 FROM pg_indexes 
        WHERE tablename = 'bathroom_requests' 
        AND indexname LIKE '%student_name%'
    );
    
END;
$$ LANGUAGE plpgsql;

-- Atualizar estatísticas de todas as tabelas
CREATE OR REPLACE FUNCTION update_table_statistics()
RETURNS VOID AS $$
DECLARE
    table_record RECORD;
BEGIN
    FOR table_record IN 
        SELECT schemaname, tablename 
        FROM pg_tables 
        WHERE schemaname = 'public'
    LOOP
        EXECUTE 'ANALYZE ' || quote_ident(table_record.schemaname) || '.' || quote_ident(table_record.tablename);
    END LOOP;
    
    RAISE NOTICE 'Statistics updated for all tables';
END;
$$ LANGUAGE plpgsql;
