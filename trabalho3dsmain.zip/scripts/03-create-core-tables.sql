-- =====================================================
-- TABELAS PRINCIPAIS DO SISTEMA
-- =====================================================

-- Tabela de tipos de usuário (lookup table)
CREATE TABLE user_types (
    id SERIAL PRIMARY KEY,
    type_name user_type_enum UNIQUE NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    permissions JSONB DEFAULT '{}',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de áreas de atuação (lookup table normalizada)
CREATE TABLE areas (
    id SERIAL PRIMARY KEY,
    area_name VARCHAR(100) UNIQUE NOT NULL,
    area_code VARCHAR(20) UNIQUE NOT NULL,
    user_type user_type_enum NOT NULL,
    description TEXT,
    color_code VARCHAR(7) DEFAULT '#6B7280', -- Hex color for UI
    icon_name VARCHAR(50) DEFAULT 'folder',
    is_active BOOLEAN DEFAULT true,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela principal de usuários
CREATE TABLE users (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    email_verified BOOLEAN DEFAULT false,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    user_type user_type_enum NOT NULL,
    area_id INTEGER REFERENCES areas(id),
    phone VARCHAR(20),
    avatar_url TEXT,
    last_login TIMESTAMP WITH TIME ZONE,
    login_count INTEGER DEFAULT 0,
    failed_login_attempts INTEGER DEFAULT 0,
    account_locked_until TIMESTAMP WITH TIME ZONE,
    password_changed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    must_change_password BOOLEAN DEFAULT false,
    two_factor_enabled BOOLEAN DEFAULT false,
    two_factor_secret VARCHAR(32),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    updated_by UUID REFERENCES users(id),
    
    -- Constraints
    CONSTRAINT valid_email CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
    CONSTRAINT valid_phone CHECK (phone IS NULL OR phone ~* '^\+?[1-9]\d{1,14}$'),
    CONSTRAINT password_not_empty CHECK (length(password_hash) > 0),
    CONSTRAINT full_name_not_empty CHECK (length(trim(full_name)) > 0)
);

-- Tabela de disciplinas
CREATE TABLE subjects (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    color_code VARCHAR(7) DEFAULT '#3B82F6',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT subject_code_format CHECK (code ~* '^[A-Z0-9_-]+$'),
    CONSTRAINT subject_name_not_empty CHECK (length(trim(name)) > 0)
);

-- Tabela de turmas
CREATE TABLE classes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(50) UNIQUE NOT NULL,
    grade_level VARCHAR(50),
    academic_year INTEGER DEFAULT EXTRACT(YEAR FROM NOW()),
    max_students INTEGER DEFAULT 40,
    current_students INTEGER DEFAULT 0,
    classroom VARCHAR(50),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    CONSTRAINT class_code_format CHECK (code ~* '^[A-Z0-9_-]+$'),
    CONSTRAINT valid_academic_year CHECK (academic_year BETWEEN 2020 AND 2030),
    CONSTRAINT valid_student_count CHECK (current_students >= 0 AND current_students <= max_students)
);

-- Tabela de horários de aula (melhorada)
CREATE TABLE class_schedules (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    class_id UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
    subject_id UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    professor_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day_of_week INTEGER NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    classroom VARCHAR(50),
    semester INTEGER DEFAULT 1 CHECK (semester IN (1, 2)),
    academic_year INTEGER DEFAULT EXTRACT(YEAR FROM NOW()),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Constraints
    CONSTRAINT valid_time_range CHECK (end_time > start_time),
    CONSTRAINT valid_semester CHECK (semester IN (1, 2)),
    CONSTRAINT valid_academic_year_schedule CHECK (academic_year BETWEEN 2020 AND 2030),
    
    -- Unique constraint para evitar conflitos de horário
    UNIQUE(professor_id, day_of_week, start_time, academic_year, semester),
    UNIQUE(classroom, day_of_week, start_time, academic_year, semester)
);
