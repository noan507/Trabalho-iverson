-- =====================================================
-- POLÍTICAS DE SEGURANÇA E RLS (Row Level Security)
-- =====================================================

-- Habilitar RLS nas tabelas sensíveis
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE exit_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE bathroom_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;

-- Função para obter o usuário atual (será definida pela aplicação)
CREATE OR REPLACE FUNCTION current_user_id()
RETURNS UUID AS $$
BEGIN
    -- Esta função será sobrescrita pela aplicação com o ID do usuário logado
    RETURN COALESCE(
        NULLIF(current_setting('app.current_user_id', true), '')::UUID,
        '00000000-0000-0000-0000-000000000000'::UUID
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Função para verificar se o usuário é admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM users 
        WHERE id = current_user_id() 
          AND user_type = 'admin' 
          AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Função para verificar se o usuário é coordenador
CREATE OR REPLACE FUNCTION is_coordinator()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM users 
        WHERE id = current_user_id() 
          AND user_type = 'coordenador' 
          AND is_active = true
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Políticas para tabela users
CREATE POLICY users_select_policy ON users
    FOR SELECT
    USING (
        is_admin() OR 
        id = current_user_id() OR
        is_coordinator()
    );

CREATE POLICY users_update_policy ON users
    FOR UPDATE
    USING (
        is_admin() OR 
        id = current_user_id()
    );

-- Políticas para exit_requests
CREATE POLICY exit_requests_select_policy ON exit_requests
    FOR SELECT
    USING (
        is_admin() OR
        is_coordinator() OR
        professor_id = current_user_id()
    );

CREATE POLICY exit_requests_insert_policy ON exit_requests
    FOR INSERT
    WITH CHECK (
        is_admin() OR
        professor_id = current_user_id()
    );

CREATE POLICY exit_requests_update_policy ON exit_requests
    FOR UPDATE
    USING (
        is_admin() OR
        is_coordinator() OR
        professor_id = current_user_id()
    );

-- Políticas para bathroom_requests
CREATE POLICY bathroom_requests_select_policy ON bathroom_requests
    FOR SELECT
    USING (
        is_admin() OR
        is_coordinator() OR
        professor_id = current_user_id()
    );

CREATE POLICY bathroom_requests_insert_policy ON bathroom_requests
    FOR INSERT
    WITH CHECK (
        is_admin() OR
        professor_id = current_user_id()
    );

CREATE POLICY bathroom_requests_update_policy ON bathroom_requests
    FOR UPDATE
    USING (
        is_admin() OR
        is_coordinator() OR
        professor_id = current_user_id()
    );

-- Políticas para activity_logs
CREATE POLICY activity_logs_select_policy ON activity_logs
    FOR SELECT
    USING (
        is_admin() OR
        is_coordinator() OR
        user_id = current_user_id()
    );

CREATE POLICY activity_logs_insert_policy ON activity_logs
    FOR INSERT
    WITH CHECK (true); -- Permitir inserção para logs do sistema

-- Políticas para audit_log (apenas admins)
CREATE POLICY audit_log_admin_only ON audit_log
    FOR ALL
    USING (is_admin());
