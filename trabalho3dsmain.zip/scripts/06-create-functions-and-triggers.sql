-- =====================================================
-- FUNÇÕES E TRIGGERS
-- =====================================================

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    NEW.updated_by = COALESCE(NEW.updated_by, OLD.updated_by);
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Função para auditoria automática
CREATE OR REPLACE FUNCTION audit_changes()
RETURNS TRIGGER AS $$
DECLARE
    old_data JSONB;
    new_data JSONB;
    changed_fields TEXT[] := '{}';
    field_name TEXT;
BEGIN
    -- Capturar dados antigos e novos
    IF TG_OP = 'DELETE' THEN
        old_data = to_jsonb(OLD);
        new_data = NULL;
    ELSIF TG_OP = 'INSERT' THEN
        old_data = NULL;
        new_data = to_jsonb(NEW);
    ELSE -- UPDATE
        old_data = to_jsonb(OLD);
        new_data = to_jsonb(NEW);
        
        -- Identificar campos alterados
        FOR field_name IN SELECT jsonb_object_keys(new_data) LOOP
            IF old_data->field_name IS DISTINCT FROM new_data->field_name THEN
                changed_fields := array_append(changed_fields, field_name);
            END IF;
        END LOOP;
    END IF;
    
    -- Inserir log de auditoria
    INSERT INTO audit_log (
        table_name,
        record_id,
        action,
        old_values,
        new_values,
        changed_fields,
        user_id,
        created_at
    ) VALUES (
        TG_TABLE_NAME,
        COALESCE(NEW.id, OLD.id),
        TG_OP,
        old_data,
        new_data,
        changed_fields,
        COALESCE(NEW.updated_by, NEW.created_by, OLD.updated_by, OLD.created_by),
        NOW()
    );
    
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- Função para gerar números sequenciais de solicitação
CREATE OR REPLACE FUNCTION generate_request_number(prefix TEXT)
RETURNS TEXT AS $$
DECLARE
    next_number INTEGER;
    formatted_number TEXT;
BEGIN
    -- Buscar próximo número baseado no prefixo e data atual
    SELECT COALESCE(MAX(
        CAST(
            SUBSTRING(request_number FROM LENGTH(prefix || TO_CHAR(CURRENT_DATE, 'YYYYMMDD')) + 1) 
            AS INTEGER
        )
    ), 0) + 1
    INTO next_number
    FROM exit_requests 
    WHERE request_number LIKE prefix || TO_CHAR(CURRENT_DATE, 'YYYYMMDD') || '%'
    
    UNION ALL
    
    SELECT COALESCE(MAX(
        CAST(
            SUBSTRING(request_number FROM LENGTH(prefix || TO_CHAR(CURRENT_DATE, 'YYYYMMDD')) + 1) 
            AS INTEGER
        )
    ), 0) + 1
    FROM bathroom_requests 
    WHERE request_number LIKE prefix || TO_CHAR(CURRENT_DATE, 'YYYYMMDD') || '%';
    
    -- Formatar número com zeros à esquerda
    formatted_number := prefix || TO_CHAR(CURRENT_DATE, 'YYYYMMDD') || LPAD(next_number::TEXT, 4, '0');
    
    RETURN formatted_number;
END;
$$ LANGUAGE plpgsql;

-- Função para verificar solicitações em atraso
CREATE OR REPLACE FUNCTION check_overdue_requests()
RETURNS INTEGER AS $$
DECLARE
    overdue_count INTEGER := 0;
BEGIN
    -- Marcar exit_requests como overdue
    UPDATE exit_requests 
    SET status = 'overdue',
        updated_at = NOW(),
        overdue_alert_sent = true
    WHERE status IN ('approved', 'student_left')
      AND return_deadline < NOW()
      AND status != 'overdue';
    
    GET DIAGNOSTICS overdue_count = ROW_COUNT;
    
    -- Marcar bathroom_requests como overdue
    UPDATE bathroom_requests 
    SET status = 'overdue',
        updated_at = NOW(),
        overdue_alert_sent = true
    WHERE status = 'student_left'
      AND exit_time + (max_duration_minutes || ' minutes')::INTERVAL < NOW()
      AND status != 'overdue';
    
    GET DIAGNOSTICS overdue_count = overdue_count + ROW_COUNT;
    
    RETURN overdue_count;
END;
$$ LANGUAGE plpgsql;

-- Triggers para updated_at
CREATE TRIGGER update_users_updated_at 
    BEFORE UPDATE ON users 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_subjects_updated_at 
    BEFORE UPDATE ON subjects 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_classes_updated_at 
    BEFORE UPDATE ON classes 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_class_schedules_updated_at 
    BEFORE UPDATE ON class_schedules 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_exit_requests_updated_at 
    BEFORE UPDATE ON exit_requests 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bathroom_requests_updated_at 
    BEFORE UPDATE ON bathroom_requests 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Triggers para auditoria
CREATE TRIGGER audit_users_changes 
    AFTER INSERT OR UPDATE OR DELETE ON users 
    FOR EACH ROW EXECUTE FUNCTION audit_changes();

CREATE TRIGGER audit_exit_requests_changes 
    AFTER INSERT OR UPDATE OR DELETE ON exit_requests 
    FOR EACH ROW EXECUTE FUNCTION audit_changes();

CREATE TRIGGER audit_bathroom_requests_changes 
    AFTER INSERT OR UPDATE OR DELETE ON bathroom_requests 
    FOR EACH ROW EXECUTE FUNCTION audit_changes();

-- Trigger para gerar números de solicitação automaticamente
CREATE OR REPLACE FUNCTION set_request_number()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.request_number IS NULL OR NEW.request_number = '' THEN
        IF TG_TABLE_NAME = 'exit_requests' THEN
            NEW.request_number := generate_request_number('EXIT');
        ELSIF TG_TABLE_NAME = 'bathroom_requests' THEN
            NEW.request_number := generate_request_number('BATH');
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_exit_request_number 
    BEFORE INSERT ON exit_requests 
    FOR EACH ROW EXECUTE FUNCTION set_request_number();

CREATE TRIGGER set_bathroom_request_number 
    BEFORE INSERT ON bathroom_requests 
    FOR EACH ROW EXECUTE FUNCTION set_request_number();
