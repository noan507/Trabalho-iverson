-- Remover tabelas existentes para recriação completa
DROP TRIGGER IF EXISTS update_users_updated_at ON users;
DROP TRIGGER IF EXISTS update_exit_requests_updated_at ON exit_requests;
DROP TRIGGER IF EXISTS update_bathroom_requests_updated_at ON bathroom_requests;
DROP TRIGGER IF EXISTS audit_users_changes ON users;
DROP TRIGGER IF EXISTS audit_exit_requests_changes ON exit_requests;

DROP FUNCTION IF EXISTS update_updated_at_column();
DROP FUNCTION IF EXISTS audit_changes();

DROP VIEW IF EXISTS active_exit_requests_view;
DROP VIEW IF EXISTS bathroom_requests_summary_view;
DROP VIEW IF EXISTS user_activity_summary_view;

DROP TABLE IF EXISTS activity_logs CASCADE;
DROP TABLE IF EXISTS bathroom_requests CASCADE;
DROP TABLE IF EXISTS exit_requests CASCADE;
DROP TABLE IF EXISTS class_schedules CASCADE;
DROP TABLE IF EXISTS user_areas CASCADE;
DROP TABLE IF EXISTS areas CASCADE;
DROP TABLE IF EXISTS user_types CASCADE;
DROP TABLE IF EXISTS classes CASCADE;
DROP TABLE IF EXISTS subjects CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS audit_log CASCADE;

-- Remover tipos customizados se existirem
DROP TYPE IF EXISTS user_type_enum CASCADE;
DROP TYPE IF EXISTS request_status_enum CASCADE;
DROP TYPE IF EXISTS bathroom_status_enum CASCADE;
