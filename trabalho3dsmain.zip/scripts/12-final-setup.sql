-- =====================================================
-- CONFIGURAÇÃO FINAL E VERIFICAÇÕES
-- =====================================================

-- Atualizar estatísticas de todas as tabelas
SELECT update_table_statistics();

-- Verificar integridade dos dados
SELECT * FROM check_data_integrity();

-- Mostrar estatísticas do sistema
SELECT system_statistics();

-- Verificar se todos os índices foram criados
SELECT 
    schemaname,
    tablename,
    indexname,
    indexdef
FROM pg_indexes 
WHERE schemaname = 'public'
ORDER BY tablename, indexname;

-- Verificar se todas as constraints estão ativas
SELECT 
    tc.table_name,
    tc.constraint_name,
    tc.constraint_type,
    cc.check_clause
FROM information_schema.table_constraints tc
LEFT JOIN information_schema.check_constraints cc 
    ON tc.constraint_name = cc.constraint_name
WHERE tc.table_schema = 'public'
ORDER BY tc.table_name, tc.constraint_type;

-- Verificar se todos os triggers estão ativos
SELECT 
    trigger_name,
    event_manipulation,
    event_object_table,
    action_statement
FROM information_schema.triggers
WHERE trigger_schema = 'public'
ORDER BY event_object_table, trigger_name;

-- Mostrar tamanho das tabelas
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size,
    pg_size_pretty(pg_relation_size(schemaname||'.'||tablename)) as table_size,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename) - pg_relation_size(schemaname||'.'||tablename)) as index_size
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;

-- Log de conclusão da instalação
INSERT INTO activity_logs (
    user_id,
    activity_type,
    description,
    metadata
) VALUES (
    NULL,
    'system_alert',
    'Database setup completed successfully',
    jsonb_build_object(
        'version', '2.0.0',
        'setup_date', NOW(),
        'tables_created', (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public'),
        'indexes_created', (SELECT COUNT(*) FROM pg_indexes WHERE schemaname = 'public'),
        'functions_created', (SELECT COUNT(*) FROM information_schema.routines WHERE routine_schema = 'public')
    )
);

-- Mensagem final
DO $$
BEGIN
    RAISE NOTICE '=================================================';
    RAISE NOTICE 'DATABASE SETUP COMPLETED SUCCESSFULLY!';
    RAISE NOTICE '=================================================';
    RAISE NOTICE 'Version: 2.0.0';
    RAISE NOTICE 'Tables: ' || (SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public');
    RAISE NOTICE 'Indexes: ' || (SELECT COUNT(*) FROM pg_indexes WHERE schemaname = 'public');
    RAISE NOTICE 'Functions: ' || (SELECT COUNT(*) FROM information_schema.routines WHERE routine_schema = 'public');
    RAISE NOTICE 'Views: ' || (SELECT COUNT(*) FROM information_schema.views WHERE table_schema = 'public');
    RAISE NOTICE '=================================================';
    RAISE NOTICE 'Ready for production use!';
    RAISE NOTICE '=================================================';
END $$;

-- Commit all changes
COMMIT;
