-- =====================================================
-- JOBS DE MANUTENÇÃO E LIMPEZA
-- =====================================================

-- Função para limpeza de logs antigos
CREATE OR REPLACE FUNCTION cleanup_old_logs()
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER := 0;
BEGIN
    -- Limpar activity_logs mais antigos que 90 dias
    DELETE FROM activity_logs 
    WHERE created_at < NOW() - INTERVAL '90 days';
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    
    -- Limpar audit_log mais antigos que 1 ano
    DELETE FROM audit_log 
    WHERE created_at < NOW() - INTERVAL '1 year';
    
    GET DIAGNOSTICS deleted_count = deleted_count + ROW_COUNT;
    
    -- Log da operação de limpeza
    INSERT INTO activity_logs (
        user_id,
        activity_type,
        description,
        metadata
    ) VALUES (
        NULL,
        'system_alert',
        'Limpeza automática de logs executada',
        jsonb_build_object('deleted_records', deleted_count)
    );
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Função para estatísticas do sistema
CREATE OR REPLACE FUNCTION system_statistics()
RETURNS JSONB AS $$
DECLARE
    stats JSONB;
BEGIN
    SELECT jsonb_build_object(
        'total_users', (SELECT COUNT(*) FROM users WHERE is_active = true),
        'total_professors', (SELECT COUNT(*) FROM users WHERE user_type = 'professor' AND is_active = true),
        'total_coordinators', (SELECT COUNT(*) FROM users WHERE user_type = 'coordenador' AND is_active = true),
        'total_fiscals', (SELECT COUNT(*) FROM users WHERE user_type = 'fiscal' AND is_active = true),
        'total_exit_requests', (SELECT COUNT(*) FROM exit_requests),
        'pending_exit_requests', (SELECT COUNT(*) FROM exit_requests WHERE status = 'pending'),
        'total_bathroom_requests', (SELECT COUNT(*) FROM bathroom_requests),
        'active_bathroom_requests', (SELECT COUNT(*) FROM bathroom_requests WHERE status IN ('pending', 'student_left')),
        'overdue_requests', (SELECT COUNT(*) FROM exit_requests WHERE status = 'overdue'),
        'database_size', pg_size_pretty(pg_database_size(current_database())),
        'last_updated', NOW()
    ) INTO stats;
    
    RETURN stats;
END;
$$ LANGUAGE plpgsql;

-- Função para backup de configurações
CREATE OR REPLACE FUNCTION backup_system_config()
RETURNS JSONB AS $$
BEGIN
    RETURN jsonb_build_object(
        'user_types', (SELECT jsonb_agg(to_jsonb(ut)) FROM user_types ut WHERE is_active = true),
        'areas', (SELECT jsonb_agg(to_jsonb(a)) FROM areas a WHERE is_active = true),
        'subjects', (SELECT jsonb_agg(to_jsonb(s)) FROM subjects s WHERE is_active = true),
        'classes', (SELECT jsonb_agg(to_jsonb(c)) FROM classes c WHERE is_active = true),
        'backup_date', NOW()
    );
END;
$$ LANGUAGE plpgsql;

-- Função para verificar integridade dos dados
CREATE OR REPLACE FUNCTION check_data_integrity()
RETURNS TABLE(
    check_name TEXT,
    status TEXT,
    details TEXT
) AS $$
BEGIN
    -- Verificar usuários órfãos (sem área válida)
    RETURN QUERY
    SELECT 
        'users_without_valid_area'::TEXT,
        CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'WARNING' END::TEXT,
        'Usuários sem área válida: ' || COUNT(*)::TEXT
    FROM users u
    LEFT JOIN areas a ON u.area_id = a.id
    WHERE u.user_type IN ('coordenador', 'fiscal') 
      AND u.is_active = true 
      AND (a.id IS NULL OR a.is_active = false);
    
    -- Verificar solicitações sem professor válido
    RETURN QUERY
    SELECT 
        'exit_requests_invalid_professor'::TEXT,
        CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'ERROR' END::TEXT,
        'Solicitações com professor inválido: ' || COUNT(*)::TEXT
    FROM exit_requests er
    LEFT JOIN users u ON er.professor_id = u.id
    WHERE u.id IS NULL OR u.is_active = false;
    
    -- Verificar solicitações de banheiro sem professor válido
    RETURN QUERY
    SELECT 
        'bathroom_requests_invalid_professor'::TEXT,
        CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'ERROR' END::TEXT,
        'Solicitações de banheiro com professor inválido: ' || COUNT(*)::TEXT
    FROM bathroom_requests br
    LEFT JOIN users u ON br.professor_id = u.id
    WHERE u.id IS NULL OR u.is_active = false;
    
    -- Verificar horários conflitantes
    RETURN QUERY
    SELECT 
        'schedule_conflicts'::TEXT,
        CASE WHEN COUNT(*) = 0 THEN 'OK' ELSE 'WARNING' END::TEXT,
        'Conflitos de horário encontrados: ' || COUNT(*)::TEXT
    FROM (
        SELECT professor_id, day_of_week, start_time, end_time, COUNT(*)
        FROM class_schedules
        WHERE is_active = true
        GROUP BY professor_id, day_of_week, start_time, end_time
        HAVING COUNT(*) > 1
    ) conflicts;
    
END;
$$ LANGUAGE plpgsql;
