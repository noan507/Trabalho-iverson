-- Inserir dados iniciais

-- Inserir disciplinas
INSERT INTO subjects (name, code) VALUES
('Matemática', 'MAT'),
('Português', 'POR'),
('História', 'HIS'),
('Geografia', 'GEO'),
('Ciências', 'CIE'),
('Inglês', 'ING'),
('Educação Física', 'EDF'),
('Artes', 'ART'),
('Ciência da Computação', 'CC'),
('Design Gráfico', 'DG')
ON CONFLICT (code) DO NOTHING;

-- Inserir turmas
INSERT INTO classes (name, code, grade_level) VALUES
('3º Ano D.S.', '3DS', 'Ensino Médio'),
('2º Ano A', '2A', 'Ensino Médio'),
('2º Ano B', '2B', 'Ensino Médio'),
('1º Ano A', '1A', 'Ensino Médio'),
('1º Ano B', '1B', 'Ensino Médio')
ON CONFLICT (code) DO NOTHING;

-- Inserir usuários (senhas são hash de 'password123')
INSERT INTO users (email, password_hash, full_name, user_type, area) VALUES
('professor1@cesf.edu.br', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQ', 'Maria Silva', 'professor', 'Matemática'),
('professor2@cesf.edu.br', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQ', 'João Santos', 'professor', 'História'),
('professor3@cesf.edu.br', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQ', 'Ana Costa', 'professor', 'Ciência da Computação'),
('coordenador@cesf.edu.br', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQ', 'Carlos Oliveira', 'coordenador', 'Pedagógico'),
('fiscal@cesf.edu.br', '$2b$10$rOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQZQZQZQZOzJqQZQZQZQZQ', 'Lucia Ferreira', 'fiscal', 'Disciplinar')
ON CONFLICT (email) DO NOTHING;
