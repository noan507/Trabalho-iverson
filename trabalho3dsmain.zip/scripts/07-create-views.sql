-- =====================================================
-- VIEWS PARA CONSULTAS OTIMIZADAS
-- =====================================================

-- View para solicitações de saída ativas com informações completas
CREATE VIEW active_exit_requests_view AS
SELECT 
    er.id,
    er.request_number,
    er.student_name,
    er.student_id,
    er.exit_time,
    er.exit_date,
    er.valid_until,
    er.reason,
    er.status,
    er.priority,
    er.created_at,
    er.return_deadline,
    
    -- Informações da turma
    c.name as class_name,
    c.code as class_code,
    c.grade_level,
    
    -- Informações do professor
    u.full_name as professor_name,
    u.email as professor_email,
    a.area_name as professor_area,
    
    -- Informações do aprovador
    approver.full_name as approved_by_name,
    er.approved_at,
    er.approval_notes,
    
    -- Cálculos de tempo
    CASE 
        WHEN er.status = 'student_left' AND er.return_deadline IS NOT NULL THEN
            EXTRACT(EPOCH FROM (er.return_deadline - NOW())) / 60
        ELSE NULL
    END as minutes_until_deadline,
    
    CASE 
        WHEN er.status = 'student_left' AND er.actual_exit_time IS NOT NULL THEN
            EXTRACT(EPOCH FROM (NOW() - er.actual_exit_time)) / 60
        ELSE NULL
    END as minutes_since_exit,
    
    -- Status calculado
    CASE 
        WHEN er.status = 'student_left' AND er.return_deadline < NOW() THEN 'overdue'
        ELSE er.status::text
    END as calculated_status

FROM exit_requests er
LEFT JOIN classes c ON er.class_id = c.id
LEFT JOIN users u ON er.professor_id = u.id
LEFT JOIN areas a ON u.area_id = a.id
LEFT JOIN users approver ON er.approved_by = approver.id
WHERE er.status NOT IN ('cancelled', 'student_returned')
ORDER BY 
    CASE er.priority WHEN 5 THEN 1 WHEN 4 THEN 2 WHEN 3 THEN 3 WHEN 2 THEN 4 ELSE 5 END,
    er.created_at DESC;

-- View para solicitações de banheiro com informações completas
CREATE VIEW bathroom_requests_summary_view AS
SELECT 
    br.id,
    br.request_number,
    br.student_name,
    br.student_id,
    br.exit_time,
    br.return_time,
    br.max_duration_minutes,
    br.status,
    br.bathroom_location,
    
    -- Informações da turma
    c.name as class_name,
    c.code as class_code,
    
    -- Informações do professor
    u.full_name as professor_name,
    u.email as professor_email,
    a.area_name as professor_area,
    
    -- Cálculos de tempo
    CASE 
        WHEN br.status = 'student_left' THEN
            EXTRACT(EPOCH FROM (NOW() - br.exit_time)) / 60
        WHEN br.return_time IS NOT NULL THEN
            EXTRACT(EPOCH FROM (br.return_time - br.exit_time)) / 60
        ELSE NULL
    END as minutes_elapsed,
    
    CASE 
        WHEN br.status = 'student_left' THEN
            br.max_duration_minutes - (EXTRACT(EPOCH FROM (NOW() - br.exit_time)) / 60)
        ELSE NULL
    END as minutes_remaining,
    
    -- Status calculado
    CASE 
        WHEN br.status = 'student_left' AND 
             br.exit_time + (br.max_duration_minutes || ' minutes')::INTERVAL < NOW() 
        THEN 'overdue'
        ELSE br.status::text
    END as calculated_status

FROM bathroom_requests br
LEFT JOIN classes c ON br.class_id = c.id
LEFT JOIN users u ON br.professor_id = u.id
LEFT JOIN areas a ON u.area_id = a.id
WHERE br.status NOT IN ('cancelled', 'student_returned')
ORDER BY br.exit_time DESC;

-- View para resumo de atividades dos usuários
CREATE VIEW user_activity_summary_view AS
SELECT 
    u.id,
    u.full_name,
    u.email,
    u.user_type,
    a.area_name,
    u.last_login,
    u.login_count,
    
    -- Contadores de atividades
    COALESCE(exit_stats.total_exit_requests, 0) as total_exit_requests,
    COALESCE(exit_stats.pending_exit_requests, 0) as pending_exit_requests,
    COALESCE(bathroom_stats.total_bathroom_requests, 0) as total_bathroom_requests,
    COALESCE(bathroom_stats.active_bathroom_requests, 0) as active_bathroom_requests,
    
    -- Atividade recente
    recent_activity.last_activity_at,
    recent_activity.last_activity_type

FROM users u
LEFT JOIN areas a ON u.area_id = a.id
LEFT JOIN (
    SELECT 
        professor_id,
        COUNT(*) as total_exit_requests,
        COUNT(*) FILTER (WHERE status = 'pending') as pending_exit_requests
    FROM exit_requests 
    WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
    GROUP BY professor_id
) exit_stats ON u.id = exit_stats.professor_id
LEFT JOIN (
    SELECT 
        professor_id,
        COUNT(*) as total_bathroom_requests,
        COUNT(*) FILTER (WHERE status IN ('pending', 'student_left')) as active_bathroom_requests
    FROM bathroom_requests 
    WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
    GROUP BY professor_id
) bathroom_stats ON u.id = bathroom_stats.professor_id
LEFT JOIN (
    SELECT DISTINCT ON (user_id)
        user_id,
        created_at as last_activity_at,
        activity_type as last_activity_type
    FROM activity_logs
    ORDER BY user_id, created_at DESC
) recent_activity ON u.id = recent_activity.user_id
WHERE u.is_active = true
ORDER BY u.last_login DESC NULLS LAST;

-- View para dashboard de coordenadores
CREATE VIEW coordinator_dashboard_view AS
SELECT 
    -- Estatísticas gerais
    (SELECT COUNT(*) FROM exit_requests WHERE status = 'pending') as pending_exit_requests,
    (SELECT COUNT(*) FROM exit_requests WHERE status = 'student_left') as students_currently_out,
    (SELECT COUNT(*) FROM bathroom_requests WHERE status = 'student_left') as students_in_bathroom,
    (SELECT COUNT(*) FROM exit_requests WHERE status = 'overdue') as overdue_students,
    
    -- Estatísticas do dia
    (SELECT COUNT(*) FROM exit_requests WHERE exit_date = CURRENT_DATE) as today_exit_requests,
    (SELECT COUNT(*) FROM bathroom_requests WHERE DATE(exit_time) = CURRENT_DATE) as today_bathroom_requests,
    
    -- Estatísticas da semana
    (SELECT COUNT(*) FROM exit_requests WHERE exit_date >= CURRENT_DATE - INTERVAL '7 days') as week_exit_requests,
    (SELECT COUNT(*) FROM bathroom_requests WHERE exit_time >= CURRENT_DATE - INTERVAL '7 days') as week_bathroom_requests;
