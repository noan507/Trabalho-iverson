-- Criar tipos enumerados para melhor consistência
CREATE TYPE user_type_enum AS ENUM (
    'professor',
    'coordenador', 
    'fiscal',
    'admin'
);

CREATE TYPE request_status_enum AS ENUM (
    'pending',
    'approved',
    'rejected',
    'student_left',
    'student_returned',
    'overdue',
    'cancelled'
);

CREATE TYPE bathroom_status_enum AS ENUM (
    'pending',
    'student_left',
    'student_returned',
    'overdue',
    'cancelled'
);

CREATE TYPE activity_type_enum AS ENUM (
    'login',
    'logout',
    'create_exit_request',
    'approve_exit_request',
    'reject_exit_request',
    'student_left',
    'student_returned',
    'create_bathroom_request',
    'bathroom_student_left',
    'bathroom_student_returned',
    'update_profile',
    'system_alert'
);
