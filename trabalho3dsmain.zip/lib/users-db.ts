// Simulação de banco de dados em memória compartilhado
class UsersDB {
  private static instance: UsersDB
  private users: any[] = [
    {
      id: '1',
      email: 'professor@cesf.edu.br',
      password: 'password123',
      full_name: 'Maria Silva',
      user_type: 'professor',
      area: 'Matemática',
      is_active: true
    },
    {
      id: '2',
      email: 'coordenador@cesf.edu.br',
      password: 'password123',
      full_name: 'Carlos Oliveira',
      user_type: 'coordenador',
      area: 'Pedagógico',
      is_active: true
    },
    {
      id: '3',
      email: 'fiscal@cesf.edu.br',
      password: 'password123',
      full_name: 'Lucia Ferreira',
      user_type: 'fiscal',
      area: 'Disciplinar',
      is_active: true
    }
  ]

  private constructor() {}

  public static getInstance(): UsersDB {
    if (!UsersDB.instance) {
      UsersDB.instance = new UsersDB()
    }
    return UsersDB.instance
  }

  public findUser(email: string, userType: string) {
    return this.users.find(u => 
      u.email.toLowerCase() === email.toLowerCase() && 
      u.user_type === userType && 
      u.is_active
    )
  }

  public findUserByEmail(email: string) {
    return this.users.find(u => 
      u.email.toLowerCase() === email.toLowerCase()
    )
  }

  public addUser(userData: any) {
    const newUser = {
      id: (this.users.length + 1).toString(),
      ...userData,
      email: userData.email.toLowerCase(),
      is_active: true,
      created_at: new Date().toISOString()
    }
    this.users.push(newUser)
    return newUser
  }

  public getAllUsers() {
    return this.users
  }

  public getUsersCount() {
    return this.users.length
  }
}

export const usersDB = UsersDB.getInstance()
